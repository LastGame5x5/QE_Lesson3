Action()
{

/*��������� �������� � ���������� �������� ������������� Think time ��� � �������!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  � �� ������� �������*/
  
  	int iterations;
    int i;
    lr_save_string("4", "NumIterations");
    iterations = atoi(lr_eval_string("{NumIterations}"));

	web_reg_save_param_regexp(
		"ParamName=csrf",
		"RegExp=name=\"csrf\" value=\"(.*?)\"",
		LAST);

	web_reg_find("Search=Body",
		"Text=https://www.linux.org.ru/news/",
		LAST);

	web_url("www.linux.org.ru", 
		"URL=https://www.linux.org.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
		
	lr_start_transaction("login1");
		
	lr_think_time(6);
		
	web_reg_find("Search=Body",
		"Text={\"loggedIn\":true}",
		LAST);
		
	web_submit_data("ajax_login_process",
		"Action=https://www.linux.org.ru/ajax_login_process",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://www.linux.org.ru/",
		"Snapshot=t3.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=csrf", "Value={csrf}", ENDITEM,
		"Name=nick", "Value={mail}", ENDITEM,
		"Name=passwd", "Value={pwd}", ENDITEM,
		LAST);
		
	web_reg_save_param_regexp(
		"ParamName=ProfileName",
		"RegExp=people/(.*?)/profile",
		LAST);
		
	web_url("www.linux.org.ru_2", 
		"URL=https://www.linux.org.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);
		
	web_url("notifications-count", 
		"URL=https://www.linux.org.ru/notifications-count?_=1684687956059", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.linux.org.ru/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);
		
	lr_end_transaction("login1",LR_AUTO);
	
	for (i = 0; i < iterations; i++) {
	
	lr_start_transaction("redact1");
	
	lr_think_time(4);
	
	lr_save_string("", "ProfileInfo");
	
	web_reg_save_param_regexp(
		"ParamName=ProfileInfo",
		"RegExp=ability to freeze a user temporary -->\\s*<p>\\s*<div>\\s*<p>((.|\\n)*?)</p>\\s*</div>",
		LAST);
	
			
	web_url("profile",
		"URL=https://www.linux.org.ru/people/{ProfileName}/profile",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://www.linux.org.ru/",
		"Snapshot=t6.inf",
		"Mode=HTML",
		LAST);

	web_url("notifications-count_2",
		"URL=https://www.linux.org.ru/notifications-count?_=1684687975184",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://www.linux.org.ru/people/{ProfileName}/profile",
		"Snapshot=t7.inf",
		"Mode=HTML",
		LAST);

	web_url("profile_2",
		"URL=https://www.linux.org.ru/people/{ProfileName}/profile?year-stats",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://www.linux.org.ru/people/{ProfileName}/profile",
		"Snapshot=t8.inf",
		"Mode=HTML",
		LAST);

	web_url("edit",
		"URL=https://www.linux.org.ru/people/{ProfileName}/edit",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://www.linux.org.ru/people/{ProfileName}/profile",
		"Snapshot=t9.inf",
		"Mode=HTML",
		LAST);

	web_url("notifications-count_3",
		"URL=https://www.linux.org.ru/notifications-count?_=1684687978427",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://www.linux.org.ru/people/{ProfileName}/edit",
		"Snapshot=t10.inf",
		"Mode=HTML",
		LAST);
	
	web_reg_find("Search=Body",
		"Text={time}",
		LAST);
		
	web_submit_data("edit_2",
		"Action=https://www.linux.org.ru/people/{ProfileName}/edit",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://www.linux.org.ru/people/{ProfileName}/edit",
		"Snapshot=t11.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=csrf", "Value={csrf}", ENDITEM,
		"Name=name", "Value=TESTS", ENDITEM,
		"Name=password", "Value=", ENDITEM,
		"Name=password2", "Value=", ENDITEM,
		"Name=url", "Value=", ENDITEM,
		"Name=email", "Value={mail}", ENDITEM,
		"Name=town", "Value=", ENDITEM,
		"Name=info", "Value={ProfileInfo}\n{time}", ENDITEM,
		"Name=oldpass", "Value={pwd}", ENDITEM,
		LAST);
	
		lr_think_time(2);
		
	web_url("notifications-count_4",
		"URL=https://www.linux.org.ru/notifications-count?_=1684688003224",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://www.linux.org.ru/people/{ProfileName}/profile",
		"Snapshot=t12.inf",
		"Mode=HTML",
		LAST);
		
	web_url("profile_3",
		"URL=https://www.linux.org.ru/people/{ProfileName}/profile?year-stats",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://www.linux.org.ru/people/{ProfileName}/profile",
		"Snapshot=t13.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("redact1",LR_AUTO);
	
	}

	lr_start_transaction("logout1");

	lr_think_time(5);

	web_url("profile_4",
		"URL=https://www.linux.org.ru/people/{ProfileName}/profile",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://www.linux.org.ru/people/{ProfileName}/profile",
		"Snapshot=t14.inf",
		"Mode=HTML",
		LAST);

	web_url("notifications-count_5",
		"URL=https://www.linux.org.ru/notifications-count?_=1684688021654",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://www.linux.org.ru/people/{ProfileName}/profile",
		"Snapshot=t15.inf",
		"Mode=HTML",
		LAST);

	web_url("profile_5",
		"URL=https://www.linux.org.ru/people/{ProfileName}/profile?year-stats",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://www.linux.org.ru/people/{ProfileName}/profile",
		"Snapshot=t16.inf",
		"Mode=HTML",
		LAST);
	
	web_reg_find(
		"Text=/login.jsp",
		LAST);

	web_submit_data("logout_all_sessions",
		"Action=https://www.linux.org.ru/logout_all_sessions",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://www.linux.org.ru/people/{ProfileName}/profile",
		"Snapshot=t17.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=csrf", "Value={csrf}", ENDITEM,
		LAST);

	lr_end_transaction("logout1",LR_AUTO);

	return 0;
}